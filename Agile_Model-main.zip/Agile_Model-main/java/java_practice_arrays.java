package com.thbs;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // arrays
//        int arr[] = new int[10];
//        //insert values
//        for (int i = 0; i < arr.length; i++) {
//            arr[i] = i;
//        }
//        //insert values 1
//        int arr1[]={10,20,30,40,50};
//        //display values
//       for (int i = 0; i < arr.length; i++) {
//            System.out.println(arr[i]);
//        }

       //take user input
//        Scanner sc=new Scanner(System.in);
//        System.out.println("enter no of elelments");
//        int n=sc.nextInt();
//        int userInputArray []= new int[n];
//        int sum = 0;
//        System.out.println("enter values for the array");
//        for (int i=0;i<n;i++){
//            userInputArray[i]=sc.nextInt();
//            sum+=userInputArray[i];
//        }
//        //display
//        System.out.println(sum);
//        for (int i = 0; i < userInputArray.length; i++) {
//            System.out.println(userInputArray[i]);
//        }

    }
}
